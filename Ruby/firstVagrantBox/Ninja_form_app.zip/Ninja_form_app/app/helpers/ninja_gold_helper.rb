module NinjaGoldHelper
end
