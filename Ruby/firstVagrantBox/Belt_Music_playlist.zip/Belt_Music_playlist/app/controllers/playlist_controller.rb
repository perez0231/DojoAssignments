class PlaylistController < ApplicationController
  def index
  end

  def create
  end

  def show
  end

  def edit
  end

  def update
  end

  def destroy
  end
end
