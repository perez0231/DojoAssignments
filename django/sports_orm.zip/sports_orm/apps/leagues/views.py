from django.shortcuts import render, redirect
from .models import League, Team, Player

from . import team_maker

def index(request):
	context = {
		"leagues": League.objects.all(),
		"teams": Team.objects.all(),
		"players": Player.objects.all(),

		"baseball_leagues": League.objects.filter(name__contains = "baseball"),
		"womens_leagues": League.objects.filter(name__contains = "Womens"),
		"hockey_leagues": League.objects.filter(name__contains = "hockey"),
		"except_football": League.objects.exclude(name= "football"),
		"conferences": League.objects.filter(name__contains= "conference"),
		"ATL_leagues": League.objects.filter(name__contains= "Atlantic"),
		"Dallas_teams": Team.objects.filter(location= "Dallas"),
		"Raptors": Team.objects.filter(team_name= "Raptors"),
		"Cities": Team.objects.filter(location__contains= "city"),
		"T_names": Team.objects.filter(team_name__startswith= "T"),
		"Alpha": Team.objects.order_by('team_name'),
		"Lnames": Team.objects.order_by('location'),
		"Reverse": Team.objects.order_by('-team_name'),
		"Coopers": Player.objects.filter(last_name= "Cooper"),
		"Joshuas": Player.objects.filter(first_name= "Joshua"),
		"hateJosh": Player.objects.filter(last_name= "Cooper").exclude(first_name= "Joshua"),
		"TheseGuys": Player.objects.filter(first_name= "Alexander")|Player.objects.filter(first_name= "Wyatt")
	}
	return render(request, "leagues/index.html", context)




def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

# 	return redirect("index")
