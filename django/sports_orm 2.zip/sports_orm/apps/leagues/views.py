from django.shortcuts import render, redirect
from models import League, Team, Player
from django.db.models import Count
from . import team_maker

def index(request):
	context = {
		"leagues": League.objects.all(),
		"teams": Team.objects.all(),
		"players": Player.objects.all(),

		"baseball_leagues": League.objects.filter(name__contains = "baseball"),
		"womens_leagues": League.objects.filter(name__contains = "Womens"),
		"hockey_leagues": League.objects.filter(name__contains = "hockey"),
		"except_football": League.objects.exclude(name= "football"),
		"conferences": League.objects.filter(name__contains= "conference"),
		"ATL_leagues": League.objects.filter(name__contains= "Atlantic"),
		"Dallas_teams": Team.objects.filter(location= "Dallas"),
		"Raptors": Team.objects.filter(team_name= "Raptors"),
		"Cities": Team.objects.filter(location__contains= "city"),
		"T_names": Team.objects.filter(team_name__startswith= "T"),
		"Alpha": Team.objects.order_by('team_name'),
		"Lnames": Team.objects.order_by('location'),
		"Reverse": Team.objects.order_by('-team_name'),
		"Coopers": Player.objects.filter(last_name= "Cooper"),
		"Joshuas": Player.objects.filter(first_name= "Joshua"),
		"hateJosh": Player.objects.filter(last_name= "Cooper").exclude(first_name= "Joshua"),
		"TheseGuys": Player.objects.filter(first_name= "Alexander")|Player.objects.filter(first_name= "Wyatt"),
		"AC_Soccer": Team.objects.filter(league__sport="Soccer"),
		"Penguins": Player.objects.filter(curr_team__team_name= "Penguins"),
		"ICBC": Player.objects.filter(curr_team__league__name="International Collegiate Baseball Conference"),
		"Lopez":Player.objects.filter(curr_team__league__name= 'American Conference of Amateur Football').filter(last_name= "Lopez"),
		"football": Player.objects.filter(curr_team__league__sport= "Football"),
		"Sophia": Team.objects.filter(curr_players__first_name="Sophia"),
		"Sophia2":League.objects.filter(teams__all_players__first_name="Sophia"),
		"Flores":Player.objects.filter(last_name= "Flores").exclude(curr_team__team_name = "Roughriders"),
		"Sam": Team.objects.filter(all_players__first_name="Samuel").filter(all_players__last_name="Evans"),
		"Tigers": Player.objects.filter(all_teams__team_name="Tiger-Cats"),
		'WV': Player.objects.filter(all_teams__team_name__contains= "Vikings").exclude(curr_team__team_name="Vikings"),
		"Colts": Team.objects.filter(all_players__last_name__contains= "Gray").filter(all_players__first_name__contains = "Jacob")& Team.objects.exclude(team_name__contains= "Colts"),
		"Joshuas": Player.objects.filter(all_teams__league__name= "Atlantic Federation of Amateur Baseball Players").filter(first_name="Joshua"),
		"12more": Team.objects.annotate(num_players=Count('all_players')).filter(num_players__gte=12),
		"PlayerTeams": Player.objects.annotate(num_team=Count('all_teams')).order_by('num_team')

	}

	return render(request, "leagues/index.html", context)




def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

# 	return redirect("index")
